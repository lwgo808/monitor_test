ErgoProj refactor bootstrap package

Files:
- ergoproj_refactor.sh: WSL script with init/test/build/serve/deploy commands
- baseline-v6/: current v6 replacement files

Recommended invocation from WSL:

bash /mnt/c/Users/rampu/Downloads/ergoproj_refactor_baseline/ergoproj_refactor.sh init \
  /mnt/c/Users/rampu/Downloads/monitor_test-master/monitor_test-master/web/ergoproj-upload

The new project will be created as ./ergoproj-product in your current WSL directory.
Set ERGOPROJ_TARGET to choose another destination.
