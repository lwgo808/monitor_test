#!/usr/bin/env bash
set -euo pipefail

# ErgoProj structural refactor/bootstrap script
#
# Usage:
#   bash ergoproj_refactor.sh init /path/to/current/ergoproj-upload
#   bash ergoproj_refactor.sh test
#   bash ergoproj_refactor.sh build
#   bash ergoproj_refactor.sh serve
#   bash ergoproj_refactor.sh deploy
#
# Defaults:
#   command: init
#   source:  current directory
#   target:  ./ergoproj-product

COMMAND="${1:-init}"
SOURCE_DIR="${2:-$PWD}"
TARGET_DIR="${ERGOPROJ_TARGET:-$PWD/ergoproj-product}"
PROJECT_NAME="${CLOUDFLARE_PAGES_PROJECT:-ergoproj}"

require_file() {
  local file="$1"
  if [[ ! -f "$file" ]]; then
    echo "ERROR: Required file not found: $file" >&2
    exit 1
  fi
}

init_project() {
  SOURCE_DIR="$(cd "$SOURCE_DIR" && pwd)"
  require_file "$SOURCE_DIR/index.html"
  require_file "$SOURCE_DIR/tracker.js"

  if [[ -e "$TARGET_DIR" ]]; then
    echo "ERROR: Target already exists: $TARGET_DIR" >&2
    echo "Move it, delete it, or set ERGOPROJ_TARGET to another location." >&2
    exit 1
  fi

  echo "Creating professional baseline at:"
  echo "  $TARGET_DIR"

  mkdir -p \
    "$TARGET_DIR/public/assets/css" \
    "$TARGET_DIR/public/assets/js" \
    "$TARGET_DIR/public/assets/icons" \
    "$TARGET_DIR/src/app" \
    "$TARGET_DIR/src/features" \
    "$TARGET_DIR/src/services" \
    "$TARGET_DIR/src/shared" \
    "$TARGET_DIR/scripts" \
    "$TARGET_DIR/tests" \
    "$TARGET_DIR/docs" \
    "$TARGET_DIR/dist"

  # Preserve an exact source snapshot before changing structure.
  mkdir -p "$TARGET_DIR/docs/baseline-v6"
  cp "$SOURCE_DIR/index.html" "$TARGET_DIR/docs/baseline-v6/index.html"
  cp "$SOURCE_DIR/tracker.js" "$TARGET_DIR/docs/baseline-v6/tracker.js"
  [[ -f "$SOURCE_DIR/firestore.rules" ]] && \
    cp "$SOURCE_DIR/firestore.rules" "$TARGET_DIR/docs/baseline-v6/firestore.rules"

  # Extract the embedded CSS, update resource paths, and preserve the HTML markup.
  python3 - "$SOURCE_DIR/index.html" "$TARGET_DIR/public/index.html" "$TARGET_DIR/public/assets/css/app.css" <<'PY'
from pathlib import Path
import re
import sys

source = Path(sys.argv[1]).read_text(encoding="utf-8")
out_html = Path(sys.argv[2])
out_css = Path(sys.argv[3])

match = re.search(r"<style>\s*(.*?)\s*</style>", source, flags=re.S)
if not match:
    raise SystemExit("ERROR: Could not locate the embedded <style> block.")

css = match.group(1).rstrip() + "\n"
html = source[:match.start()] + '<link rel="stylesheet" href="assets/css/app.css?v=1">\n' + source[match.end():]

html = re.sub(
    r'<script\s+type="module"\s+src="tracker\.js\?v=[^"]+"\s*></script>',
    '<script type="module" src="assets/js/app.js?v=1"></script>',
    html
)

out_css.write_text(css, encoding="utf-8")
out_html.write_text(html, encoding="utf-8")
PY

  # Stage 1 deliberately preserves the tested JavaScript behavior.
  cp "$SOURCE_DIR/tracker.js" "$TARGET_DIR/public/assets/js/app.js"

  if [[ -f "$SOURCE_DIR/firestore.rules" ]]; then
    cp "$SOURCE_DIR/firestore.rules" "$TARGET_DIR/firestore.rules"
  else
    cat > "$TARGET_DIR/firestore.rules" <<'RULES'
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /likes/{userId} {
      allow read: if true;
      allow create: if request.auth != null
                    && request.auth.uid == userId
                    && request.resource.data.keys().hasOnly(['likedAt']);
      allow delete: if request.auth != null
                    && request.auth.uid == userId;
      allow update: if false;
    }
    match /suggestions/{suggestionId} {
      allow create: if request.auth != null
                    && request.resource.data.userId == request.auth.uid;
      allow read, update, delete: if false;
    }
    match /users/{userId}/profiles/{profileId} {
      allow read, write: if request.auth != null
                         && request.auth.uid == userId;
    }
    match /users/{userId}/sessions/{sessionId} {
      allow read, create, delete: if request.auth != null
                                  && request.auth.uid == userId;
      allow update: if false;
    }
    match /{document=**} {
      allow read, write: if false;
    }
  }
}
RULES
  fi

  cat > "$TARGET_DIR/public/assets/icons/favicon.svg" <<'SVG'
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">
  <rect width="64" height="64" rx="14" fill="#333745"/>
  <path d="M20 14h28v8H29v8h16v8H29v8h19v8H20z" fill="#EEF5DB"/>
  <circle cx="48" cy="18" r="6" fill="#E63462"/>
</svg>
SVG

  python3 - "$TARGET_DIR/public/index.html" <<'PY'
from pathlib import Path
import sys

path = Path(sys.argv[1])
html = path.read_text(encoding="utf-8")
needle = '<meta name="theme-color" content="#333745" />'
replacement = needle + '\n<link rel="icon" href="assets/icons/favicon.svg" type="image/svg+xml" />'
if 'assets/icons/favicon.svg' not in html:
    html = html.replace(needle, replacement)
path.write_text(html, encoding="utf-8")
PY

  cat > "$TARGET_DIR/src/README.md" <<'MD'
# Planned JavaScript module boundary

The production baseline currently runs from `public/assets/js/app.js` without
behavior changes. New features must not be added directly to that file.

The next refactor should extract one module at a time into:

- `app/` — startup, lifecycle and state coordination
- `features/camera/` — camera permission and stream lifecycle
- `features/tracking/` — MediaPipe initialization and inference scheduling
- `features/posture/` — metric calculation, scoring and recommendations
- `features/calibration/` — profiles and personal baselines
- `features/alerts/` — visual, sound and notification escalation
- `features/session/` — summaries, history and export
- `features/ui/` — tabs, controls and rendering
- `services/firebase/` — authentication, likes, suggestions and optional sync
- `services/storage/` — localStorage/IndexedDB persistence
- `shared/` — constants, formatting, validation and browser capabilities

Each extraction must preserve the smoke-test contract and be committed
separately.
MD

  cat > "$TARGET_DIR/docs/ARCHITECTURE.md" <<'MD'
# ErgoProj baseline architecture

## Goal

Create a stable professional project structure while preserving the complete v6
feature set. This stage intentionally avoids functional changes.

## Runtime layers

1. `public/index.html`
   - Semantic application shell
   - Live monitoring workspace
   - Summary, History, Setup and Feedback tabs
2. `public/assets/css/app.css`
   - Responsive visual system
   - Desktop and mobile layouts
3. `public/assets/js/app.js`
   - Current tested application behavior
   - MediaPipe face tracking
   - Calibration, scoring, session summary and graphs
   - Firebase likes, suggestions, profiles and sessions
4. `firestore.rules`
   - Firebase authorization contract

## Refactor sequence

### R0 — Structural baseline

- Externalize CSS
- Move browser assets under `public/assets`
- Add build, test, serve and deploy scripts
- Keep JavaScript behavior unchanged

### R1 — Shared foundations

Extract constants, formatting, DOM lookup helpers, state definitions and
capability detection. No algorithm changes.

### R2 — Service boundaries

Extract local persistence and Firebase integration. The posture pipeline must
work even when Firebase is unavailable.

### R3 — Camera and model lifecycle

Extract camera acquisition, MediaPipe loading, stream cleanup, visibility
handling and error mapping.

### R4 — Posture domain

Extract metric calculation, thresholds, calibration, scoring and
recommendations into pure functions that can be unit tested.

### R5 — Session and history

Extract aggregation, summaries, graph series and optional cloud persistence.

### R6 — Alerts and UI

Extract state rendering, tabs, mute controls, break reminders and future sound
or notification escalation.

## Non-negotiable rules

- Camera processing remains local.
- No-login mode remains fully functional.
- Firebase failure must not prevent posture tracking.
- New modules must not access arbitrary DOM nodes; UI access belongs in the UI
  layer.
- Metric and scoring functions should accept data and return data.
- Camera tracks must stop on session end and page teardown.
- Build output is always generated into `dist/`.
MD

  cat > "$TARGET_DIR/tests/smoke.py" <<'PY'
#!/usr/bin/env python3
from pathlib import Path
import re
import sys

root = Path(__file__).resolve().parents[1]
public = root / "public"
html_path = public / "index.html"
css_path = public / "assets/css/app.css"
js_path = public / "assets/js/app.js"

errors = []

for path in (html_path, css_path, js_path):
    if not path.is_file():
        errors.append(f"Missing required file: {path.relative_to(root)}")

if errors:
    print("\n".join(f"FAIL: {e}" for e in errors))
    sys.exit(1)

html = html_path.read_text(encoding="utf-8")
css = css_path.read_text(encoding="utf-8")
js = js_path.read_text(encoding="utf-8")

required_ids = {
    "video", "canvas", "btn-start", "btn-restart", "btn-stop",
    "status-badge", "status-text", "posture-score",
    "m-distance", "m-hoffset", "m-voffset", "m-pitch", "m-yaw", "m-roll",
    "alerts-list", "btn-calibrate", "profile-select", "posture-mode",
    "sensitivity", "alert-delay", "break-interval",
    "btn-mute-alerts", "mute-duration", "btn-presentation-mode",
    "summary-duration", "summary-good-percent", "summary-score",
    "summary-streak", "summary-issue", "btn-save-session",
    "gc-distance", "gc-hoff", "gc-voff", "gc-pitch", "gc-yaw", "gc-roll",
    "btn-like", "like-count", "comment-text", "comment-name",
    "btn-send-comment", "comment-status"
}

found_ids = set(re.findall(r'\bid="([^"]+)"', html))
missing_ids = sorted(required_ids - found_ids)
if missing_ids:
    errors.append("Missing required HTML IDs: " + ", ".join(missing_ids))

duplicate_ids = sorted({
    item for item in found_ids
    if len(re.findall(rf'\bid="{re.escape(item)}"', html)) > 1
})
if duplicate_ids:
    errors.append("Duplicate HTML IDs: " + ", ".join(duplicate_ids))

if 'assets/css/app.css?v=1' not in html:
    errors.append("index.html does not reference the external stylesheet")

if 'assets/js/app.js?v=1' not in html:
    errors.append("index.html does not reference the application module")

if '<style>' in html:
    errors.append("Embedded style block remains in index.html")

required_js_tokens = (
    "FaceLandmarker",
    "navigator.mediaDevices.getUserMedia",
    "startCalibration",
    "calculatePostureScore",
    "finishSession",
    "initSocialFeatures",
    "setReadyState",
    "setNoFaceState"
)
for token in required_js_tokens:
    if token not in js:
        errors.append(f"Expected application behavior token missing: {token}")

if len(css) < 5000:
    errors.append("CSS output appears unexpectedly small")

if errors:
    print("\n".join(f"FAIL: {e}" for e in errors))
    sys.exit(1)

print("PASS: Static smoke contract is intact.")
print(f"PASS: {len(found_ids)} unique HTML IDs found.")
print("PASS: Current camera, posture, calibration, session and Firebase hooks remain present.")
PY
  chmod +x "$TARGET_DIR/tests/smoke.py"

  cat > "$TARGET_DIR/scripts/test.sh" <<'SH'
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

python3 "$ROOT/tests/smoke.py"

if command -v node >/dev/null 2>&1; then
  node --check "$ROOT/public/assets/js/app.js"
  echo "PASS: JavaScript syntax check."
else
  echo "NOTE: Node.js is not installed; skipped node --check."
fi

python3 - "$ROOT/public/index.html" <<'PY'
from html.parser import HTMLParser
from pathlib import Path
import sys

class Parser(HTMLParser):
    pass

parser = Parser()
parser.feed(Path(sys.argv[1]).read_text(encoding="utf-8"))
print("PASS: HTML parser accepted index.html.")
PY
SH
  chmod +x "$TARGET_DIR/scripts/test.sh"

  cat > "$TARGET_DIR/scripts/build.sh" <<'SH'
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

"$ROOT/scripts/test.sh"

rm -rf "$ROOT/dist"
mkdir -p "$ROOT/dist"
cp -a "$ROOT/public/." "$ROOT/dist/"

echo "PASS: Build generated at $ROOT/dist"
SH
  chmod +x "$TARGET_DIR/scripts/build.sh"

  cat > "$TARGET_DIR/scripts/serve.sh" <<'SH'
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PORT="${PORT:-8000}"

cd "$ROOT/public"
echo "Serving static files at http://0.0.0.0:$PORT"
echo "Camera testing requires HTTPS or a browser-recognized localhost origin."
python3 -m http.server "$PORT"
SH
  chmod +x "$TARGET_DIR/scripts/serve.sh"

  cat > "$TARGET_DIR/scripts/deploy.sh" <<SH
#!/usr/bin/env bash
set -euo pipefail
ROOT="\$(cd "\$(dirname "\${BASH_SOURCE[0]}")/.." && pwd)"
PROJECT_NAME="\${CLOUDFLARE_PAGES_PROJECT:-$PROJECT_NAME}"

"\$ROOT/scripts/build.sh"

if ! command -v npx >/dev/null 2>&1; then
  echo "ERROR: npx is required for Cloudflare deployment." >&2
  echo "Install Node.js/npm, then rerun this script." >&2
  exit 1
fi

echo "Deploying dist/ to Cloudflare Pages project: \$PROJECT_NAME"
cd "\$ROOT"
npx --yes wrangler@4 pages deploy dist --project-name "\$PROJECT_NAME"
SH
  chmod +x "$TARGET_DIR/scripts/deploy.sh"

  cat > "$TARGET_DIR/.gitignore" <<'TXT'
dist/
node_modules/
.wrangler/
.dev.vars
.DS_Store
*.backup
TXT

  cat > "$TARGET_DIR/README.md" <<'MD'
# ErgoProj product baseline

This directory is a behavior-preserving structural refactor of ErgoProj v6.

## Commands

```bash
./scripts/test.sh
./scripts/build.sh
./scripts/serve.sh
./scripts/deploy.sh
```

## Local camera testing

A webcam page requires HTTPS or a secure localhost origin.

If WSL `localhost` forwarding is unreliable, run the server from Windows
PowerShell:

```powershell
cd C:\path\to\ergoproj-product\public
py -m http.server 8000
```

Then open:

```text
http://localhost:8000
```

For the strongest end-to-end test, deploy to Cloudflare Pages and use the HTTPS
preview URL.

## Deployment

The deployment script uses Wrangler:

```bash
./scripts/deploy.sh
```

On first use, Wrangler may ask you to authenticate with Cloudflare.

Set a different Pages project name with:

```bash
CLOUDFLARE_PAGES_PROJECT=my-project ./scripts/deploy.sh
```

## Firestore

`firestore.rules` remains outside `public/` so it is not deployed as a public
website asset. Publish it through Firebase Console or Firebase CLI separately.
MD

  cat > "$TARGET_DIR/package.json" <<'JSON'
{
  "name": "ergoproj",
  "private": true,
  "version": "0.6.0-structure.1",
  "scripts": {
    "test": "bash scripts/test.sh",
    "build": "bash scripts/build.sh",
    "serve": "bash scripts/serve.sh",
    "deploy": "bash scripts/deploy.sh"
  },
  "devDependencies": {
    "wrangler": "4.24.3"
  }
}
JSON

  echo
  echo "Running baseline tests..."
  "$TARGET_DIR/scripts/test.sh"
  "$TARGET_DIR/scripts/build.sh"

  echo
  echo "SUCCESS"
  echo "Project: $TARGET_DIR"
  echo
  echo "Next commands:"
  echo "  cd \"$TARGET_DIR\""
  echo "  ./scripts/test.sh"
  echo "  ./scripts/serve.sh"
  echo "  ./scripts/deploy.sh"
}

case "$COMMAND" in
  init)
    init_project
    ;;
  test)
    "$TARGET_DIR/scripts/test.sh"
    ;;
  build)
    "$TARGET_DIR/scripts/build.sh"
    ;;
  serve)
    "$TARGET_DIR/scripts/serve.sh"
    ;;
  deploy)
    "$TARGET_DIR/scripts/deploy.sh"
    ;;
  *)
    echo "Usage: $0 {init|test|build|serve|deploy} [source-directory]" >&2
    exit 2
    ;;
esac
