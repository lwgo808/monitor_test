// ── ErgoProj tracker.js ──────────────────────────────────────────────────────
// MediaPipe processing stays local. Firebase stores only explicit social data,
// optional calibration profiles, and aggregate session summaries.

import {
  FaceLandmarker,
  FilesetResolver,
} from "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/vision_bundle.mjs";

import { initializeApp } from "https://www.gstatic.com/firebasejs/12.16.0/firebase-app.js";
import {
  getAuth,
  signInAnonymously,
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.16.0/firebase-auth.js";
import {
  getFirestore,
  collection,
  doc,
  getDoc,
  setDoc,
  deleteDoc,
  addDoc,
  onSnapshot,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.16.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyCC8vOjS7ZuVP54JUZc1hoH4dV2QD3Lsb8",
  authDomain: "ergoproj.firebaseapp.com",
  projectId: "ergoproj",
  storageBucket: "ergoproj.firebasestorage.app",
  messagingSenderId: "76644208172",
  appId: "1:76644208172:web:5da6358aa34e1eb76acb89",
  measurementId: "G-XH7SRLXS9B"
};

const firebaseApp = initializeApp(firebaseConfig);
const auth = getAuth(firebaseApp);
const db = getFirestore(firebaseApp);

// ── Constants ─────────────────────────────────────────────────────────────────
const LEFT_EYE = 468;
const RIGHT_EYE = 473;
const NOSE_TIP = 1;

const STANDARD_TARGET = Object.freeze({
  distanceCm: 60,
  hOffset: 0,
  vOffset: 0,
  pitch: 0,
  yaw: 0,
  roll: 0
});

const STANDARD_LIMITS = Object.freeze({
  distanceMin: 50,
  distanceMax: 70,
  hOffset: 40,
  vOffset: 0.08,
  pitch: 15,
  yaw: 15,
  roll: 10
});

const ABSOLUTE_LIMITS = Object.freeze({
  distanceMin: 40,
  distanceMax: 90,
  hOffset: 120,
  vOffset: 0.25,
  pitch: 30,
  yaw: 35,
  roll: 25
});

const SENSITIVITY = Object.freeze({
  relaxed:  { distance: 15, hOffset: 55, vOffset: 0.12, pitch: 18, yaw: 20, roll: 14 },
  balanced: { distance: 10, hOffset: 40, vOffset: 0.08, pitch: 15, yaw: 15, roll: 10 },
  strict:   { distance: 7,  hOffset: 25, vOffset: 0.05, pitch: 10, yaw: 10, roll: 7 }
});

const SCORE_WEIGHTS = Object.freeze({
  distance: 20,
  hOffset: 15,
  vOffset: 20,
  pitch: 20,
  yaw: 15,
  roll: 10
});

const KNOWN_FACE_WIDTH_CM = 14.0;
const FOCAL_LENGTH_PX = 600.0;
const CALIBRATION_DURATION_MS = 5000;
const SNAPSHOT_INTERVAL_MS = 10000;
const MAX_SNAPSHOTS = 60;
const NO_FACE_CLEAR_DELAY_MS = 1500;

const LS_SETTINGS = "ergoproj_settings_v3";
const LS_PROFILES = "ergoproj_profiles_v3";

const DEFAULT_SETTINGS = Object.freeze({
  mode: "standard",
  sensitivity: "balanced",
  alertDelayMs: 5000,
  breakIntervalMin: 45,
  activeProfileId: "default"
});

const DEFAULT_PROFILE = Object.freeze({
  id: "default",
  name: "Default Desk",
  baseline: null,
  updatedAt: null
});

// ── State ─────────────────────────────────────────────────────────────────────
let settings = loadJson(LS_SETTINGS, { ...DEFAULT_SETTINGS });
let profiles = loadJson(LS_PROFILES, { default: { ...DEFAULT_PROFILE } });
if (!profiles.default) profiles.default = { ...DEFAULT_PROFILE };
if (!profiles[settings.activeProfileId]) settings.activeProfileId = "default";

let currentFirebaseUser = null;
let latestMetrics = null;
let latestEvaluation = null;
let latestScore = null;
let latestSessionSummary = null;
let appTrackingState = "idle";
let lastFaceSeenAt = 0;

let calibrationState = {
  active: false,
  startedAt: 0,
  samples: []
};

let issueStartedAt = {};
let alertsMutedUntil = 0;
let muteUntilSessionEnds = false;
let muteCountdownTimerId = null;
let presentationMode = false;
let breakTimerId = null;

let session = createEmptySession();

const _accum = { distanceCm: [], hOffset: [], vOffset: [], pitch: [], yaw: [], roll: [] };
const _series = { distanceCm: [], hOffset: [], vOffset: [], pitch: [], yaw: [], roll: [] };
let _lastSnapshotTime = performance.now();

// ── Utilities ─────────────────────────────────────────────────────────────────
function loadJson(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (error) {
    console.warn(`Unable to load ${key}:`, error);
    return fallback;
  }
}

function saveLocalState() {
  localStorage.setItem(LS_SETTINGS, JSON.stringify(settings));
  localStorage.setItem(LS_PROFILES, JSON.stringify(profiles));
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function average(values) {
  return values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : 0;
}

function formatDuration(ms) {
  const totalSeconds = Math.max(0, Math.floor(ms / 1000));
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return minutes ? `${minutes}m ${seconds}s` : `${seconds}s`;
}

function slugify(value) {
  return value.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 32);
}

function createEmptySession() {
  return {
    startedAtMs: null,
    endedAtMs: null,
    lastUpdateMs: null,
    totalTrackedMs: 0,
    goodTrackedMs: 0,
    scoreWeightedSum: 0,
    currentGoodStreakMs: 0,
    longestGoodStreakMs: 0,
    issueDurationsMs: {
      distance: 0,
      hOffset: 0,
      vOffset: 0,
      pitch: 0,
      yaw: 0,
      roll: 0
    }
  };
}

function activeProfile() {
  return profiles[settings.activeProfileId] || profiles.default;
}

function currentBaseline() {
  return settings.mode === "personal" && activeProfile().baseline
    ? activeProfile().baseline
    : STANDARD_TARGET;
}

function currentTolerance() {
  return SENSITIVITY[settings.sensitivity] || SENSITIVITY.balanced;
}

// ── Metric extraction ─────────────────────────────────────────────────────────
function estimateDistance(faceWidthPx) {
  if (faceWidthPx <= 0) return 0;
  return (KNOWN_FACE_WIDTH_CM * FOCAL_LENGTH_PX) / faceWidthPx;
}

function extractHeadAngles(matrix) {
  const R = [
    [matrix[0], matrix[1], matrix[2]],
    [matrix[4], matrix[5], matrix[6]],
    [matrix[8], matrix[9], matrix[10]],
  ];
  const toDeg = radians => radians * (180 / Math.PI);
  return {
    pitch: toDeg(Math.asin(-R[2][0])),
    yaw: toDeg(Math.atan2(R[1][0], R[0][0])),
    roll: toDeg(Math.atan2(R[2][1], R[2][2]))
  };
}

function computeMetrics(result, W, H) {
  if (!result?.faceLandmarks?.length) return null;

  const lm = result.faceLandmarks[0];
  const lx = lm[LEFT_EYE].x * W;
  const ly = lm[LEFT_EYE].y * H;
  const rx = lm[RIGHT_EYE].x * W;
  const ry = lm[RIGHT_EYE].y * H;
  const nx = lm[NOSE_TIP].x * W;
  const ny = lm[NOSE_TIP].y * H;

  const eyeMidX = (lx + rx) / 2;
  const eyeMidY = (ly + ry) / 2;
  const faceWidthPx = Math.hypot(rx - lx, ry - ly);

  let pitch = 0;
  let yaw = 0;
  let roll = 0;

  if (result.facialTransformationMatrixes?.length) {
    ({ pitch, yaw, roll } = extractHeadAngles(result.facialTransformationMatrixes[0].data));
  }

  return {
    distanceCm: estimateDistance(faceWidthPx),
    hOffset: eyeMidX - W / 2,
    vOffset: (ny - H / 2) / H,
    pitch,
    yaw,
    roll,
    eyeMidX,
    eyeMidY,
    nx,
    ny
  };
}

// ── Evaluation, grace period, and score ──────────────────────────────────────
function rawIssueMap(metrics) {
  const baseline = currentBaseline();
  const tolerance = currentTolerance();
  const personal = settings.mode === "personal" && activeProfile().baseline;

  const distanceOk = personal
    ? Math.abs(metrics.distanceCm - baseline.distanceCm) <= tolerance.distance
    : metrics.distanceCm >= STANDARD_LIMITS.distanceMin && metrics.distanceCm <= STANDARD_LIMITS.distanceMax;

  return {
    distance: !distanceOk ||
      metrics.distanceCm < ABSOLUTE_LIMITS.distanceMin ||
      metrics.distanceCm > ABSOLUTE_LIMITS.distanceMax,

    hOffset:
      Math.abs(metrics.hOffset - baseline.hOffset) > tolerance.hOffset ||
      Math.abs(metrics.hOffset) > ABSOLUTE_LIMITS.hOffset,

    vOffset:
      Math.abs(metrics.vOffset - baseline.vOffset) > tolerance.vOffset ||
      Math.abs(metrics.vOffset) > ABSOLUTE_LIMITS.vOffset,

    pitch:
      Math.abs(metrics.pitch - baseline.pitch) > tolerance.pitch ||
      Math.abs(metrics.pitch) > ABSOLUTE_LIMITS.pitch,

    yaw:
      Math.abs(metrics.yaw - baseline.yaw) > tolerance.yaw ||
      Math.abs(metrics.yaw) > ABSOLUTE_LIMITS.yaw,

    roll:
      Math.abs(metrics.roll - baseline.roll) > tolerance.roll ||
      Math.abs(metrics.roll) > ABSOLUTE_LIMITS.roll
  };
}

function issueMessage(key, metrics) {
  const baseline = currentBaseline();

  switch (key) {
    case "distance":
      if (settings.mode === "personal" && activeProfile().baseline) {
        return `Return near your calibrated distance (${baseline.distanceCm.toFixed(0)} cm).`;
      }
      return metrics.distanceCm < STANDARD_LIMITS.distanceMin
        ? `Move back — too close (${metrics.distanceCm.toFixed(0)} cm).`
        : `Move closer — too far (${metrics.distanceCm.toFixed(0)} cm).`;

    case "hOffset":
      return `Re-center relative to your camera (${Math.abs(metrics.hOffset - baseline.hOffset).toFixed(0)} px deviation).`;

    case "vOffset":
      return `Adjust monitor or seat height (${Math.abs((metrics.vOffset - baseline.vOffset) * 100).toFixed(1)}% vertical deviation).`;

    case "pitch":
      return `Reduce head pitch deviation (${Math.abs(metrics.pitch - baseline.pitch).toFixed(1)}°).`;

    case "yaw":
      return `Face the screen more directly (${Math.abs(metrics.yaw - baseline.yaw).toFixed(1)}° yaw deviation).`;

    case "roll":
      return `Straighten your head (${Math.abs(metrics.roll - baseline.roll).toFixed(1)}° roll deviation).`;

    default:
      return "Adjust your posture.";
  }
}

function evaluate(metrics, nowMs = performance.now()) {
  const raw = rawIssueMap(metrics);

  for (const [key, active] of Object.entries(raw)) {
    if (active && issueStartedAt[key] == null) issueStartedAt[key] = nowMs;
    if (!active) delete issueStartedAt[key];
  }

  const delayed = {};
  for (const key of Object.keys(raw)) {
    delayed[key] = raw[key] &&
      issueStartedAt[key] != null &&
      nowMs - issueStartedAt[key] >= settings.alertDelayMs;
  }

  if (presentationMode) {
    delayed.hOffset = false;
    delayed.yaw = false;
  }

  const muted = muteUntilSessionEnds || Date.now() < alertsMutedUntil;
  const activeKeys = Object.keys(delayed).filter(key => delayed[key]);
  const messages = muted ? [] : activeKeys.map(key => issueMessage(key, metrics));

  return {
    ok: activeKeys.length === 0,
    muted,
    rawIssues: raw,
    delayedIssues: delayed,
    activeKeys,
    msgs: messages
  };
}

function normalizedPenalty(deviation, tolerance) {
  return clamp(deviation / Math.max(tolerance, 0.0001), 0, 2) / 2;
}

function calculatePostureScore(metrics) {
  const baseline = currentBaseline();
  const tolerance = currentTolerance();

  const penalties = {
    distance: normalizedPenalty(Math.abs(metrics.distanceCm - baseline.distanceCm), tolerance.distance),
    hOffset: normalizedPenalty(Math.abs(metrics.hOffset - baseline.hOffset), tolerance.hOffset),
    vOffset: normalizedPenalty(Math.abs(metrics.vOffset - baseline.vOffset), tolerance.vOffset),
    pitch: normalizedPenalty(Math.abs(metrics.pitch - baseline.pitch), tolerance.pitch),
    yaw: normalizedPenalty(Math.abs(metrics.yaw - baseline.yaw), tolerance.yaw),
    roll: normalizedPenalty(Math.abs(metrics.roll - baseline.roll), tolerance.roll)
  };

  let lost = 0;
  for (const [key, weight] of Object.entries(SCORE_WEIGHTS)) {
    lost += penalties[key] * weight;
  }
  return Math.round(clamp(100 - lost, 0, 100));
}


function setTrackingControlsEnabled(enabled) {
  const ids = [
    "btn-mute-alerts",
    "mute-duration",
    "btn-presentation-mode"
  ];

  ids.forEach(id => {
    const element = document.getElementById(id);
    if (element) element.disabled = !enabled;
  });

  const canCalibrate = enabled && !!latestMetrics;
  ["btn-calibrate", "btn-calibrate-secondary"].forEach(id => {
    const button = document.getElementById(id);
    if (button) button.disabled = !canCalibrate || calibrationState.active;
  });
}

function setMeasurementState(text) {
  const element = document.getElementById("measurement-state");
  if (element) element.textContent = text;
}

function clearLiveMeasurements({ preserveLast = false } = {}) {
  if (!preserveLast) {
    const metricIds = ["m-distance", "m-hoffset", "m-voffset", "m-pitch", "m-yaw", "m-roll"];
    metricIds.forEach(id => {
      const element = document.getElementById(id);
      if (element) {
        element.textContent = "—";
        element.className = "metric-value";
      }
    });

    const scoreEl = document.getElementById("posture-score");
    if (scoreEl) {
      scoreEl.textContent = "—";
      scoreEl.className = "score-box";
    }

    const scoreLabel = document.getElementById("posture-score-label");
    if (scoreLabel) scoreLabel.textContent = "Not available";

    const scoreDetail = document.getElementById("score-detail");
    if (scoreDetail) scoreDetail.textContent = "Start tracking to calculate your posture score.";
  }
}

function setReadyState() {
  appTrackingState = "idle";
  const badge = document.getElementById("status-badge");
  const statusText = document.getElementById("status-text");

  if (badge) badge.className = "";
  if (statusText) statusText.textContent = "Ready to start";

  setMeasurementState("Not tracking");
  clearLiveMeasurements();
  setTrackingControlsEnabled(false);

  const alerts = document.getElementById("alerts-list");
  if (alerts) {
    alerts.innerHTML = '<div class="alert-none">Start tracking to see recommendations.</div>';
  }

  const saveButton = document.getElementById("btn-save-session");
  if (saveButton) saveButton.disabled = true;

  const dismissBreak = document.getElementById("btn-dismiss-break");
  if (dismissBreak) dismissBreak.disabled = true;
}

function setStartingState() {
  appTrackingState = "starting";
  const badge = document.getElementById("status-badge");
  const statusText = document.getElementById("status-text");

  if (badge) badge.className = "";
  if (statusText) statusText.textContent = "Starting camera…";

  setMeasurementState("Starting…");
  clearLiveMeasurements();
  setTrackingControlsEnabled(false);
}

function setNoFaceState() {
  const badge = document.getElementById("status-badge");
  const statusText = document.getElementById("status-text");

  if (badge) badge.className = "error";
  if (statusText) statusText.textContent = "No face detected";

  setMeasurementState("No face detected");
  clearLiveMeasurements();

  const alerts = document.getElementById("alerts-list");
  if (alerts) {
    alerts.innerHTML = '<div class="info-item">Position your face clearly inside the camera view.</div>';
  }

  setTrackingControlsEnabled(true);
}

function setStoppedState() {
  appTrackingState = "stopped";
  const badge = document.getElementById("status-badge");
  const statusText = document.getElementById("status-text");

  if (badge) badge.className = "";
  if (statusText) statusText.textContent = "Session stopped";

  setMeasurementState(latestMetrics ? "Last reading" : "No reading");
  setTrackingControlsEnabled(false);

  const scoreDetail = document.getElementById("score-detail");
  if (scoreDetail && latestMetrics) {
    scoreDetail.textContent = "Last recorded posture score from the completed session.";
  }

  const saveButton = document.getElementById("btn-save-session");
  if (saveButton) saveButton.disabled = !latestSessionSummary;
}

function activateTab(tabId) {
  const buttons = [...document.querySelectorAll(".tab-button")];
  const panels = [...document.querySelectorAll(".tab-panel")];

  buttons.forEach(button => {
    button.classList.toggle("active", button.dataset.tab === tabId);
  });
  panels.forEach(panel => {
    panel.classList.toggle("active", panel.id === tabId);
  });

  if (tabId === "history-panel") {
    requestAnimationFrame(() => GRAPH_CFG.forEach(drawGraph));
  }
}

// ── UI helpers ────────────────────────────────────────────────────────────────
function metricClass(ok) {
  return ok ? "ok" : "bad";
}

function gaugeClass(percent) {
  return percent < 0.6 ? "" : percent < 1 ? "warn" : "bad";
}

function setMetric(id, text, ok) {
  const element = document.getElementById(id);
  if (!element) return;
  element.textContent = text;
  element.className = `metric-value ${metricClass(ok)}`;
}

function setGauge(baseId, deviation, limit) {
  const fill = document.getElementById(baseId);
  const value = document.getElementById(`${baseId}-val`);
  if (!fill || !value) return;

  const pct = clamp(Math.abs(deviation) / Math.max(limit, 0.001), 0, 1);
  fill.style.width = `${(pct * 100).toFixed(1)}%`;
  fill.className = `gauge-fill ${gaugeClass(pct)}`;
  value.textContent = `${deviation >= 0 ? "+" : ""}${deviation.toFixed(1)}°`;
}

function updatePanel(metrics, evaluation, score) {
  const baseline = currentBaseline();
  const tolerance = currentTolerance();
  const raw = evaluation.rawIssues;

  const badge = document.getElementById("status-badge");
  const statusText = document.getElementById("status-text");

  if (evaluation.muted) {
    badge.className = "muted";
    statusText.textContent = "Alerts muted";
  } else {
    badge.className = evaluation.ok ? "ok" : "warn";
    statusText.textContent = evaluation.ok
      ? "Posture OK ✓"
      : `${evaluation.activeKeys.length} persistent issue${evaluation.activeKeys.length === 1 ? "" : "s"}`;
  }

  setMetric("m-distance", `${metrics.distanceCm.toFixed(0)} cm`, !raw.distance);
  setMetric("m-hoffset", `${metrics.hOffset >= 0 ? "+" : ""}${metrics.hOffset.toFixed(0)} px`, !raw.hOffset);
  setMetric("m-voffset", `${(metrics.vOffset * 100).toFixed(1)}%`, !raw.vOffset);
  setMetric("m-pitch", `${metrics.pitch.toFixed(1)}°`, !raw.pitch);
  setMetric("m-yaw", `${metrics.yaw.toFixed(1)}°`, !raw.yaw);
  setMetric("m-roll", `${metrics.roll.toFixed(1)}°`, !raw.roll);

  setGauge("g-pitch", metrics.pitch - baseline.pitch, tolerance.pitch);
  setGauge("g-yaw", metrics.yaw - baseline.yaw, tolerance.yaw);
  setGauge("g-roll", metrics.roll - baseline.roll, tolerance.roll);

  const scoreEl = document.getElementById("posture-score");
  const labelEl = document.getElementById("posture-score-label");
  const detailEl = document.getElementById("score-detail");

  scoreEl.textContent = score;
  scoreEl.className = score >= 80 ? "good" : score >= 60 ? "fair" : "poor";
  labelEl.textContent = score >= 80 ? "Good alignment" : score >= 60 ? "Needs attention" : "Adjust posture";
  detailEl.textContent = settings.mode === "personal" && activeProfile().baseline
    ? `Compared with profile “${activeProfile().name}” using ${settings.sensitivity} sensitivity.`
    : `Compared with standard ergonomic defaults using ${settings.sensitivity} sensitivity.`;

  const list = document.getElementById("alerts-list");
  list.innerHTML = "";

  if (evaluation.muted) {
    const muteText = muteUntilSessionEnds
      ? "Alerts are muted until this tracking session ends."
      : `Alerts are muted for ${formatMuteRemaining()} more.`;
    list.innerHTML = `<div class="info-item">${muteText}</div>`;
  } else if (evaluation.msgs.length) {
    for (const message of evaluation.msgs) {
      const item = document.createElement("div");
      item.className = "alert-item";
      item.textContent = `⚠ ${message}`;
      list.appendChild(item);
    }
  } else if (Object.values(raw).some(Boolean)) {
    list.innerHTML = `<div class="info-item">A deviation was detected. The ${settings.alertDelayMs / 1000}-second grace period is preventing a premature alert.</div>`;
  } else {
    list.innerHTML = '<div class="alert-none">Posture looks good — keep it up!</div>';
  }
}

function refreshCalibrationUI() {
  const profile = activeProfile();
  const modeSelect = document.getElementById("posture-mode");
  const sensitivitySelect = document.getElementById("sensitivity");
  const alertDelaySelect = document.getElementById("alert-delay");
  const breakSelect = document.getElementById("break-interval");

  if (modeSelect) modeSelect.value = settings.mode;
  if (sensitivitySelect) sensitivitySelect.value = settings.sensitivity;
  if (alertDelaySelect) alertDelaySelect.value = String(settings.alertDelayMs);
  if (breakSelect) breakSelect.value = String(settings.breakIntervalMin);

  const status = document.getElementById("calibration-status");
  if (!status) return;

  if (calibrationState.active) {
    status.textContent = "Hold your preferred upright posture and look naturally at the screen.";
  } else if (profile.baseline) {
    const b = profile.baseline;
    status.textContent =
      `Profile “${profile.name}” calibrated: ${b.distanceCm.toFixed(0)} cm, ` +
      `${b.hOffset.toFixed(0)} px horizontal, ${(b.vOffset * 100).toFixed(1)}% vertical, ` +
      `pitch ${b.pitch.toFixed(1)}°, yaw ${b.yaw.toFixed(1)}°, roll ${b.roll.toFixed(1)}°.`;
  } else {
    status.textContent = "No personal calibration saved for this profile. Standard ergonomic defaults are active.";
  }
}

function refreshProfileSelect() {
  const select = document.getElementById("profile-select");
  if (!select) return;
  select.innerHTML = "";

  for (const profile of Object.values(profiles)) {
    const option = document.createElement("option");
    option.value = profile.id;
    option.textContent = profile.name;
    select.appendChild(option);
  }
  select.value = settings.activeProfileId;
  refreshCalibrationUI();
}

// ── Calibration and profiles ──────────────────────────────────────────────────
function startCalibration() {
  if (appTrackingState !== "tracking" || !latestMetrics) {
    alert("Start tracking and keep your face visible before calibrating.");
    return;
  }

  calibrationState = {
    active: true,
    startedAt: performance.now(),
    samples: []
  };

  const calibrationButtons = [
    document.getElementById("btn-calibrate"),
    document.getElementById("btn-calibrate-secondary")
  ].filter(Boolean);

  calibrationButtons.forEach(button => {
    button.disabled = true;
    button.textContent = "Calibrating…";
  });
  refreshCalibrationUI();
}

function updateCalibration(metrics, nowMs) {
  if (!calibrationState.active) return;

  calibrationState.samples.push({
    distanceCm: metrics.distanceCm,
    hOffset: metrics.hOffset,
    vOffset: metrics.vOffset,
    pitch: metrics.pitch,
    yaw: metrics.yaw,
    roll: metrics.roll
  });

  const elapsed = nowMs - calibrationState.startedAt;
  const pct = clamp(elapsed / CALIBRATION_DURATION_MS, 0, 1);
  const fill = document.getElementById("calibration-progress-fill");
  if (fill) fill.style.width = `${(pct * 100).toFixed(0)}%`;

  if (elapsed >= CALIBRATION_DURATION_MS) finishCalibration();
}

function finishCalibration() {
  const samples = calibrationState.samples;
  calibrationState.active = false;

  const calibrationButtons = [
    document.getElementById("btn-calibrate"),
    document.getElementById("btn-calibrate-secondary")
  ].filter(Boolean);

  calibrationButtons.forEach(button => {
    button.disabled = !(appTrackingState === "tracking" && latestMetrics);
    button.textContent = "Set My Ideal Position";
  });

  if (samples.length < 10) {
    const status = document.getElementById("calibration-status");
    if (status) status.textContent = "Calibration failed: not enough stable face measurements.";
    return;
  }

  const baseline = {
    distanceCm: average(samples.map(sample => sample.distanceCm)),
    hOffset: average(samples.map(sample => sample.hOffset)),
    vOffset: average(samples.map(sample => sample.vOffset)),
    pitch: average(samples.map(sample => sample.pitch)),
    yaw: average(samples.map(sample => sample.yaw)),
    roll: average(samples.map(sample => sample.roll))
  };

  const profile = activeProfile();
  profile.baseline = baseline;
  profile.updatedAt = new Date().toISOString();
  settings.mode = "personal";
  saveLocalState();

  const fill = document.getElementById("calibration-progress-fill");
  if (fill) fill.style.width = "100%";

  syncActiveProfileToFirebase().catch(error => console.warn("Profile sync failed:", error));
  refreshCalibrationUI();
  updateSetupSummaries();
}

function resetCalibration() {
  const profile = activeProfile();
  profile.baseline = null;
  profile.updatedAt = new Date().toISOString();
  settings.mode = "standard";
  saveLocalState();
  issueStartedAt = {};

  const fill = document.getElementById("calibration-progress-fill");
  if (fill) fill.style.width = "0%";

  syncActiveProfileToFirebase().catch(error => console.warn("Profile sync failed:", error));
  refreshCalibrationUI();
  updateSetupSummaries();
}

function createProfile() {
  const name = prompt("Profile name, for example Home Desk or Standing Desk:");
  if (!name?.trim()) return;

  let id = slugify(name);
  if (!id) id = `profile-${Date.now()}`;

  let uniqueId = id;
  let suffix = 2;
  while (profiles[uniqueId]) uniqueId = `${id}-${suffix++}`;

  profiles[uniqueId] = {
    id: uniqueId,
    name: name.trim().slice(0, 60),
    baseline: null,
    updatedAt: new Date().toISOString()
  };

  settings.activeProfileId = uniqueId;
  settings.mode = "standard";
  saveLocalState();
  refreshProfileSelect();
  updateSetupSummaries();
}

function deleteActiveProfile() {
  if (settings.activeProfileId === "default") {
    alert("The Default Desk profile cannot be deleted.");
    return;
  }

  const profile = activeProfile();
  if (!confirm(`Delete profile “${profile.name}”?`)) return;

  const deletedId = profile.id;
  delete profiles[deletedId];
  settings.activeProfileId = "default";
  settings.mode = profiles.default.baseline ? "personal" : "standard";
  saveLocalState();

  if (currentFirebaseUser) {
    deleteDoc(doc(db, "users", currentFirebaseUser.uid, "profiles", deletedId))
      .catch(error => console.warn("Unable to delete cloud profile:", error));
  }

  refreshProfileSelect();
  updateSetupSummaries();
}

// ── Session tracking ──────────────────────────────────────────────────────────
function startSession() {
  session = createEmptySession();
  session.startedAtMs = Date.now();
  session.lastUpdateMs = performance.now();
  latestSessionSummary = null;
  updateSummaryUI(null);
}

function updateSession(evaluation, score, nowMs) {
  if (!session.startedAtMs || session.lastUpdateMs == null) return;

  const delta = clamp(nowMs - session.lastUpdateMs, 0, 1000);
  session.lastUpdateMs = nowMs;
  session.totalTrackedMs += delta;
  session.scoreWeightedSum += score * delta;

  if (evaluation.ok) {
    session.goodTrackedMs += delta;
    session.currentGoodStreakMs += delta;
    session.longestGoodStreakMs = Math.max(session.longestGoodStreakMs, session.currentGoodStreakMs);
  } else {
    session.currentGoodStreakMs = 0;
  }

  for (const [key, active] of Object.entries(evaluation.rawIssues)) {
    if (active) session.issueDurationsMs[key] += delta;
  }
}

function finishSession() {
  if (!session.startedAtMs) return null;

  session.endedAtMs = Date.now();
  const averageScore = session.totalTrackedMs
    ? Math.round(session.scoreWeightedSum / session.totalTrackedMs)
    : 0;

  const goodPercent = session.totalTrackedMs
    ? Math.round((session.goodTrackedMs / session.totalTrackedMs) * 100)
    : 0;

  const mostCommonEntry = Object.entries(session.issueDurationsMs)
    .sort((a, b) => b[1] - a[1])[0];

  const issueLabels = {
    distance: "Distance",
    hOffset: "Horizontal alignment",
    vOffset: "Monitor height",
    pitch: "Pitch",
    yaw: "Yaw",
    roll: "Roll"
  };

  latestSessionSummary = {
    startedAtIso: new Date(session.startedAtMs).toISOString(),
    endedAtIso: new Date(session.endedAtMs).toISOString(),
    durationSeconds: Math.round(session.totalTrackedMs / 1000),
    goodPosturePercent: goodPercent,
    averageScore,
    longestGoodStreakSeconds: Math.round(session.longestGoodStreakMs / 1000),
    mostCommonIssue: mostCommonEntry && mostCommonEntry[1] > 0
      ? issueLabels[mostCommonEntry[0]]
      : "None",
    profileId: settings.activeProfileId,
    profileName: activeProfile().name,
    mode: settings.mode,
    sensitivity: settings.sensitivity
  };

  updateSummaryUI(latestSessionSummary);
  return latestSessionSummary;
}

function updateSummaryUI(summary) {
  const emptyState = document.getElementById("summary-empty-state");
  if (emptyState) emptyState.hidden = !!summary;

  const saveButton = document.getElementById("btn-save-session");
  if (saveButton) saveButton.disabled = !summary;

  document.getElementById("summary-duration").textContent = summary ? formatDuration(summary.durationSeconds * 1000) : "—";
  document.getElementById("summary-good-percent").textContent = summary ? `${summary.goodPosturePercent}%` : "—";
  document.getElementById("summary-score").textContent = summary ? `${summary.averageScore}/100` : "—";
  document.getElementById("summary-streak").textContent = summary ? formatDuration(summary.longestGoodStreakSeconds * 1000) : "—";
  document.getElementById("summary-issue").textContent = summary ? summary.mostCommonIssue : "—";
}


// ── Alert mute controls ───────────────────────────────────────────────────────
function isAlertsMuted() {
  return muteUntilSessionEnds || Date.now() < alertsMutedUntil;
}

function formatMuteRemaining() {
  if (muteUntilSessionEnds) return "this session";
  const remainingMs = Math.max(0, alertsMutedUntil - Date.now());
  const totalSeconds = Math.ceil(remainingMs / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return minutes > 0
    ? `${minutes}m ${String(seconds).padStart(2, "0")}s`
    : `${seconds}s`;
}

function updateMuteButton() {
  const button = document.getElementById("btn-mute-alerts");
  const duration = document.getElementById("mute-duration");
  if (!button || !duration) return;

  const muted = isAlertsMuted();
  button.textContent = muted
    ? (muteUntilSessionEnds ? "Unmute alerts" : `Unmute alerts (${formatMuteRemaining()})`)
    : "Mute alerts";

  button.classList.toggle("btn-primary", muted);
  button.classList.toggle("btn-secondary", !muted);
  duration.disabled = appTrackingState !== "tracking" || muted;
  button.disabled = appTrackingState !== "tracking";
}

function startMuteCountdown() {
  if (muteCountdownTimerId) clearInterval(muteCountdownTimerId);

  muteCountdownTimerId = setInterval(() => {
    if (!muteUntilSessionEnds && alertsMutedUntil && Date.now() >= alertsMutedUntil) {
      alertsMutedUntil = 0;
    }

    updateMuteButton();

    if (!isAlertsMuted() && muteCountdownTimerId) {
      clearInterval(muteCountdownTimerId);
      muteCountdownTimerId = null;
    }
  }, 1000);
}

function toggleAlertsMute() {
  if (isAlertsMuted()) {
    alertsMutedUntil = 0;
    muteUntilSessionEnds = false;

    if (muteCountdownTimerId) {
      clearInterval(muteCountdownTimerId);
      muteCountdownTimerId = null;
    }

    updateMuteButton();
    return;
  }

  const selected = document.getElementById("mute-duration").value;

  if (selected === "session") {
    muteUntilSessionEnds = true;
    alertsMutedUntil = 0;
  } else {
    muteUntilSessionEnds = false;
    alertsMutedUntil = Date.now() + Number(selected) * 60 * 1000;
  }

  updateMuteButton();
  startMuteCountdown();
}

// ── Break reminders ───────────────────────────────────────────────────────────
function configureBreakTimer() {
  const dismissButton = document.getElementById("btn-dismiss-break");
  if (dismissButton) dismissButton.disabled = true;

  if (breakTimerId) {
    clearInterval(breakTimerId);
    breakTimerId = null;
  }

  document.getElementById("break-reminder").hidden = true;
  if (!settings.breakIntervalMin) return;

  breakTimerId = setInterval(() => {
    document.getElementById("break-reminder").hidden = false;
    if (dismissButton) dismissButton.disabled = false;
  }, settings.breakIntervalMin * 60 * 1000);
}

// ── Graph engine ──────────────────────────────────────────────────────────────
const GRAPH_CFG = [
  { key: "distanceCm", canvas: "gc-distance", stats: "gs-dist", unit: "cm", band: [STANDARD_LIMITS.distanceMin, STANDARD_LIMITS.distanceMax] },
  { key: "hOffset", canvas: "gc-hoff", stats: "gs-hoff", unit: "px", band: [-STANDARD_LIMITS.hOffset, STANDARD_LIMITS.hOffset] },
  { key: "vOffset", canvas: "gc-voff", stats: "gs-voff", unit: "%", band: [-STANDARD_LIMITS.vOffset * 100, STANDARD_LIMITS.vOffset * 100] },
  { key: "pitch", canvas: "gc-pitch", stats: "gs-pitch", unit: "°", band: [-STANDARD_LIMITS.pitch, STANDARD_LIMITS.pitch] },
  { key: "yaw", canvas: "gc-yaw", stats: "gs-yaw", unit: "°", band: [-STANDARD_LIMITS.yaw, STANDARD_LIMITS.yaw] },
  { key: "roll", canvas: "gc-roll", stats: "gs-roll", unit: "°", band: [-STANDARD_LIMITS.roll, STANDARD_LIMITS.roll] }
];

function accumulate(metrics) {
  _accum.distanceCm.push(metrics.distanceCm);
  _accum.hOffset.push(metrics.hOffset);
  _accum.vOffset.push(metrics.vOffset * 100);
  _accum.pitch.push(metrics.pitch);
  _accum.yaw.push(metrics.yaw);
  _accum.roll.push(metrics.roll);

  const now = performance.now();
  if (now - _lastSnapshotTime < SNAPSHOT_INTERVAL_MS) return;
  _lastSnapshotTime = now;

  for (const key of Object.keys(_accum)) {
    const values = _accum[key];
    if (!values.length) continue;

    _series[key].push({
      avg: average(values),
      hi: Math.max(...values),
      lo: Math.min(...values)
    });

    if (_series[key].length > MAX_SNAPSHOTS) _series[key].shift();
    _accum[key] = [];
  }

  GRAPH_CFG.forEach(drawGraph);
}

function drawGraph(cfg) {
  const series = _series[cfg.key];
  const noDataEl = document.getElementById(cfg.canvas.replace("gc-", "gnd-"));
  const canvas = document.getElementById(cfg.canvas);
  if (!canvas) return;

  if (!series.length) {
    if (noDataEl) noDataEl.style.display = "flex";
    return;
  }
  if (noDataEl) noDataEl.style.display = "none";

  const rect = canvas.parentElement.getBoundingClientRect();
  const W = Math.floor(rect.width) || 300;
  const H = Math.floor(rect.height) || 100;
  canvas.width = W;
  canvas.height = H;

  const ctx = canvas.getContext("2d");
  ctx.clearRect(0, 0, W, H);

  const allHi = series.map(point => point.hi);
  const allLo = series.map(point => point.lo);
  const allAvg = series.map(point => point.avg);
  let dataMax = Math.max(...allHi, cfg.band?.[1] ?? -Infinity);
  let dataMin = Math.min(...allLo, cfg.band?.[0] ?? Infinity);

  const span = dataMax - dataMin || 1;
  const pad = span * 0.15;
  const vMax = dataMax + pad;
  const vMin = dataMin - pad;
  const vSpan = vMax - vMin;

  const PAD_L = 38, PAD_R = 10, PAD_T = 8, PAD_B = 18;
  const gW = W - PAD_L - PAD_R;
  const gH = H - PAD_T - PAD_B;

  const yPx = value => PAD_T + gH - ((value - vMin) / vSpan) * gH;
  const xPx = index => series.length === 1
    ? PAD_L + gW / 2
    : PAD_L + (index / (series.length - 1)) * gW;

  if (cfg.band) {
    const y1 = yPx(cfg.band[1]);
    const y2 = yPx(cfg.band[0]);
    ctx.fillStyle = "rgba(16,185,129,0.08)";
    ctx.fillRect(PAD_L, Math.min(y1, y2), gW, Math.abs(y2 - y1));
    ctx.strokeStyle = "rgba(16,185,129,0.25)";
    ctx.setLineDash([4, 4]);
    for (const y of [y1, y2]) {
      ctx.beginPath();
      ctx.moveTo(PAD_L, y);
      ctx.lineTo(PAD_L + gW, y);
      ctx.stroke();
    }
    ctx.setLineDash([]);
  }

  ctx.fillStyle = "#475569";
  ctx.font = "9px monospace";
  ctx.textAlign = "right";
  [vMax, (vMax + vMin) / 2, vMin].forEach(value => {
    const y = yPx(value);
    ctx.fillText(cfg.unit === "%" ? `${value.toFixed(1)}%` : value.toFixed(0), PAD_L - 4, y + 3);
    ctx.strokeStyle = "#1a1f2e";
    ctx.beginPath();
    ctx.moveTo(PAD_L, y);
    ctx.lineTo(PAD_L + gW, y);
    ctx.stroke();
  });

  ctx.beginPath();
  series.forEach((point, index) => ctx.lineTo(xPx(index), yPx(point.hi)));
  series.slice().reverse().forEach((point, index) =>
    ctx.lineTo(xPx(series.length - 1 - index), yPx(point.lo))
  );
  ctx.closePath();
  ctx.fillStyle = "rgba(99,179,255,0.12)";
  ctx.fill();

  ctx.beginPath();
  series.forEach((point, index) => {
    if (index === 0) ctx.moveTo(xPx(index), yPx(point.avg));
    else ctx.lineTo(xPx(index), yPx(point.avg));
  });
  ctx.strokeStyle = "#60a5fa";
  ctx.lineWidth = 2;
  ctx.stroke();

  series.forEach((point, index) => {
    const inBand = !cfg.band || (point.avg >= cfg.band[0] && point.avg <= cfg.band[1]);
    ctx.beginPath();
    ctx.arc(xPx(index), yPx(point.avg), 3.5, 0, Math.PI * 2);
    ctx.fillStyle = inBand ? "#6ee7b7" : "#f87171";
    ctx.fill();
  });

  ctx.fillStyle = "#334155";
  ctx.font = "9px monospace";
  ctx.textAlign = "center";
  const step = Math.max(1, Math.floor(series.length / 5));
  series.forEach((_, index) => {
    if (index % step === 0 || index === series.length - 1) {
      const secondsAgo = (series.length - 1 - index) * 10;
      ctx.fillText(secondsAgo ? `-${secondsAgo}s` : "now", xPx(index), H - 4);
    }
  });

  const overallAvg = average(allAvg);
  const overallHi = Math.max(...allHi);
  const overallLo = Math.min(...allLo);
  const fmt = value => cfg.unit === "%"
    ? `${value >= 0 ? "+" : ""}${value.toFixed(1)}%`
    : cfg.unit === "cm"
      ? `${value.toFixed(0)}cm`
      : `${value >= 0 ? "+" : ""}${value.toFixed(1)}${cfg.unit}`;

  document.getElementById(`${cfg.stats}-hi`).textContent = `hi ${fmt(overallHi)}`;
  document.getElementById(`${cfg.stats}-avg`).textContent = `avg ${fmt(overallAvg)}`;
  document.getElementById(`${cfg.stats}-lo`).textContent = `lo ${fmt(overallLo)}`;
}

// ── Main camera loop ──────────────────────────────────────────────────────────
async function main() {
  const video = document.getElementById("video");
  const canvas = document.getElementById("canvas");
  const ctx = canvas.getContext("2d");
  const btnStart = document.getElementById("btn-start");
  const btnRestart = document.getElementById("btn-restart");
  const btnStop = document.getElementById("btn-stop");
  const loadingMsg = document.getElementById("loading-msg");
  const startOverlay = document.getElementById("start-overlay");
  const stoppedOverlay = document.getElementById("stopped-overlay");

  let landmarker = null;
  let stream = null;
  let running = false;
  let rafId = null;

  async function initLandmarker() {
    const vision = await FilesetResolver.forVisionTasks(
      "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm"
    );

    return FaceLandmarker.createFromOptions(vision, {
      baseOptions: {
        modelAssetPath:
          "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/latest/face_landmarker.task",
        delegate: "GPU"
      },
      runningMode: "VIDEO",
      numFaces: 1,
      minFaceDetectionConfidence: 0.5,
      minFacePresenceConfidence: 0.5,
      minTrackingConfidence: 0.5,
      outputFaceBlendshapes: false,
      outputFacialTransformationMatrixes: true
    });
  }

  async function startTracking() {
    setStartingState();
    btnStart.disabled = true;
    btnRestart.disabled = true;
    loadingMsg.style.display = "block";
    loadingMsg.textContent = "Loading AI model…";
    loadingMsg.style.color = "#E63462";

    try {
      if (!landmarker) landmarker = await initLandmarker();

      stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: "user",
          width: { ideal: 1280 },
          height: { ideal: 720 }
        }
      });

      video.srcObject = stream;
      await new Promise(resolve => { video.onloadedmetadata = resolve; });
      await video.play();

      startOverlay.style.display = "none";
      stoppedOverlay.style.display = "none";
      loadingMsg.style.display = "none";
      btnStop.style.display = "block";
      btnStart.disabled = false;
      btnRestart.disabled = false;
      running = true;
      appTrackingState = "tracking";
      lastFaceSeenAt = performance.now();
      issueStartedAt = {};
      muteUntilSessionEnds = false;
      alertsMutedUntil = 0;
      updateMuteButton();
      setMeasurementState("Tracking");
      setTrackingControlsEnabled(true);
      configureBreakTimer();
      startSession();

      let lastVideoTime = -1;

      function loop() {
        if (!running) return;

        const W = video.videoWidth;
        const H = video.videoHeight;
        if (!W || !H) {
          rafId = requestAnimationFrame(loop);
          return;
        }

        canvas.width = W;
        canvas.height = H;
        ctx.clearRect(0, 0, W, H);

        if (video.currentTime !== lastVideoTime) {
          lastVideoTime = video.currentTime;
          const nowMs = performance.now();
          const result = landmarker.detectForVideo(video, nowMs);
          const metrics = computeMetrics(result, W, H);

          if (metrics) {
            latestMetrics = metrics;
            lastFaceSeenAt = nowMs;
            appTrackingState = "tracking";
            setMeasurementState("Live");
            setTrackingControlsEnabled(true);

            updateCalibration(metrics, nowMs);

            const evaluation = evaluate(metrics, nowMs);
            const score = calculatePostureScore(metrics);

            latestEvaluation = evaluation;
            latestScore = score;

            updatePanel(metrics, evaluation, score);
            updateSession(evaluation, score, nowMs);
            accumulate(metrics);
          } else if (nowMs - lastFaceSeenAt >= NO_FACE_CLEAR_DELAY_MS) {
            latestMetrics = null;
            latestEvaluation = null;
            latestScore = null;
            setNoFaceState();
          }
        }

        rafId = requestAnimationFrame(loop);
      }

      rafId = requestAnimationFrame(loop);
    } catch (error) {
      loadingMsg.textContent = `Error: ${error.message}`;
      loadingMsg.style.color = "#f87171";
      loadingMsg.style.display = "block";
      btnStart.disabled = false;
      btnRestart.disabled = false;
      setReadyState();
      console.error(error);
    }
  }

  function stopTracking() {
    running = false;

    if (rafId) {
      cancelAnimationFrame(rafId);
      rafId = null;
    }

    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      stream = null;
    }

    if (breakTimerId) {
      clearInterval(breakTimerId);
      breakTimerId = null;
    }

    muteUntilSessionEnds = false;
    alertsMutedUntil = 0;
    if (muteCountdownTimerId) {
      clearInterval(muteCountdownTimerId);
      muteCountdownTimerId = null;
    }
    updateMuteButton();

    if (calibrationState.active) {
      calibrationState.active = false;
      ["btn-calibrate", "btn-calibrate-secondary"].forEach(id => {
        const button = document.getElementById(id);
        if (button) {
          button.disabled = false;
          button.textContent = "Set My Ideal Position";
        }
      });
    }

    video.srcObject = null;
    btnStop.style.display = "none";
    stoppedOverlay.style.display = "flex";
    latestSessionSummary = finishSession();
    setStoppedState();
    activateTab("summary-panel");
  }

  btnStart.addEventListener("click", startTracking);
  btnRestart.addEventListener("click", startTracking);
  btnStop.addEventListener("click", stopTracking);
}

main();

// ── Firebase social data, profiles, and sessions ─────────────────────────────
async function syncActiveProfileToFirebase() {
  if (!currentFirebaseUser) return;

  const profile = activeProfile();
  await setDoc(
    doc(db, "users", currentFirebaseUser.uid, "profiles", profile.id),
    {
      name: profile.name,
      baseline: profile.baseline,
      updatedAt: serverTimestamp()
    },
    { merge: true }
  );
}

async function saveSessionSummaryToFirebase() {
  const status = document.getElementById("cloud-status");

  if (!currentFirebaseUser) {
    status.textContent = "Still connecting to Firebase.";
    status.className = "err-text";
    return;
  }

  if (!latestSessionSummary) {
    status.textContent = "Stop a tracking session first.";
    status.className = "err-text";
    return;
  }

  status.textContent = "Saving…";
  status.className = "";

  try {
    await addDoc(
      collection(db, "users", currentFirebaseUser.uid, "sessions"),
      {
        ...latestSessionSummary,
        createdAt: serverTimestamp()
      }
    );
    status.textContent = "✓ Session summary saved.";
    status.className = "ok-text";
  } catch (error) {
    console.error("Unable to save session summary:", error);
    status.textContent = "Unable to save session summary.";
    status.className = "err-text";
  }
}

async function initSocialFeatures() {
  const btnLike = document.getElementById("btn-like");
  const likeCount = document.getElementById("like-count");
  const btnSend = document.getElementById("btn-send-comment");
  const commentText = document.getElementById("comment-text");
  const commentName = document.getElementById("comment-name");
  const commentStatus = document.getElementById("comment-status");

  let hasLiked = false;
  let likeBusy = false;
  btnLike.disabled = true;

  function renderLikeState() {
    btnLike.classList.toggle("liked", hasLiked);
    btnLike.querySelector(".heart").textContent = hasLiked ? "♥" : "♡";
  }

  onSnapshot(
    collection(db, "likes"),
    snapshot => {
      likeCount.textContent = snapshot.size.toLocaleString();
    },
    error => {
      console.error("Unable to read Heart count:", error);
      likeCount.textContent = "—";
    }
  );

  onAuthStateChanged(auth, async user => {
    if (!user) return;

    currentFirebaseUser = user;

    try {
      const likeDoc = await getDoc(doc(db, "likes", user.uid));
      hasLiked = likeDoc.exists();
      renderLikeState();
      btnLike.disabled = false;
    } catch (error) {
      console.error("Unable to load Heart state:", error);
    }
  });

  try {
    await signInAnonymously(auth);
  } catch (error) {
    console.error("Anonymous sign-in failed:", error);
    btnLike.disabled = true;
    likeCount.textContent = "—";
    commentStatus.textContent = "Online features are temporarily unavailable.";
    commentStatus.className = "err-text";
  }

  btnLike.addEventListener("click", async () => {
    if (!currentFirebaseUser || likeBusy) return;

    likeBusy = true;
    btnLike.disabled = true;
    const previous = hasLiked;
    const ref = doc(db, "likes", currentFirebaseUser.uid);

    try {
      if (hasLiked) {
        await deleteDoc(ref);
        hasLiked = false;
      } else {
        await setDoc(ref, { likedAt: serverTimestamp() });
        hasLiked = true;
      }
      renderLikeState();
    } catch (error) {
      hasLiked = previous;
      renderLikeState();
      console.error("Unable to update Heart:", error);
    } finally {
      likeBusy = false;
      btnLike.disabled = false;
    }
  });

  btnSend.addEventListener("click", async () => {
    const message = (commentText.value || "").trim();
    const name = (commentName.value || "").trim() || "Anonymous";

    if (!message) {
      commentStatus.textContent = "Please write a suggestion before sending.";
      commentStatus.className = "err-text";
      return;
    }

    if (!currentFirebaseUser) {
      commentStatus.textContent = "Still connecting. Please try again.";
      commentStatus.className = "err-text";
      return;
    }

    btnSend.disabled = true;
    commentStatus.textContent = "Sending…";
    commentStatus.className = "";

    try {
      await addDoc(collection(db, "suggestions"), {
        name,
        message,
        createdAt: serverTimestamp(),
        userId: currentFirebaseUser.uid
      });

      commentStatus.textContent = "✓ Suggestion received. Thank you!";
      commentStatus.className = "ok-text";
      commentText.value = "";
      commentName.value = "";
    } catch (error) {
      console.error("Unable to submit suggestion:", error);
      commentStatus.textContent = "Unable to send the suggestion. Please try again.";
      commentStatus.className = "err-text";
    } finally {
      btnSend.disabled = false;
    }
  });
}


function updateSetupSummaries() {
  const profileSummary = document.getElementById("setup-profile-summary");
  const alertSummary = document.getElementById("setup-alert-summary");
  const breakSummary = document.getElementById("setup-break-summary");

  if (profileSummary) {
    profileSummary.textContent =
      `${activeProfile().name} • ${settings.mode === "personal" ? "Personal" : "Standard"} mode`;
  }

  if (alertSummary) {
    const label = settings.sensitivity.charAt(0).toUpperCase() + settings.sensitivity.slice(1);
    alertSummary.textContent = `${label} • ${settings.alertDelayMs / 1000}-second delay`;
  }

  if (breakSummary) {
    breakSummary.textContent = settings.breakIntervalMin
      ? `Every ${settings.breakIntervalMin} minutes`
      : "Off";
  }
}

function initTabs() {
  const buttons = [...document.querySelectorAll(".tab-button")];
  const panels = [...document.querySelectorAll(".tab-panel")];

  buttons.forEach(button => {
    button.addEventListener("click", () => activateTab(button.dataset.tab));
  });
}

// ── Control wiring ────────────────────────────────────────────────────────────
function initControls() {
  refreshProfileSelect();
  refreshCalibrationUI();
  updateSummaryUI(null);
  initTabs();
  updateSetupSummaries();
  setReadyState();

  document.getElementById("btn-calibrate").addEventListener("click", startCalibration);
  document.getElementById("btn-calibrate-secondary")?.addEventListener("click", startCalibration);
  document.getElementById("btn-reset-calibration").addEventListener("click", resetCalibration);
  document.getElementById("btn-new-profile").addEventListener("click", createProfile);
  document.getElementById("btn-delete-profile").addEventListener("click", deleteActiveProfile);
  document.getElementById("btn-save-session").addEventListener("click", saveSessionSummaryToFirebase);

  document.getElementById("profile-select").addEventListener("change", event => {
    settings.activeProfileId = event.target.value;
    settings.mode = activeProfile().baseline ? "personal" : "standard";
    issueStartedAt = {};
    saveLocalState();
    refreshCalibrationUI();
    updateSetupSummaries();
  });

  document.getElementById("posture-mode").addEventListener("change", event => {
    if (event.target.value === "personal" && !activeProfile().baseline) {
      alert("Calibrate this profile before using personal mode.");
      event.target.value = "standard";
      settings.mode = "standard";
    } else {
      settings.mode = event.target.value;
    }
    issueStartedAt = {};
    saveLocalState();
    refreshCalibrationUI();
  });

  document.getElementById("sensitivity").addEventListener("change", event => {
    settings.sensitivity = event.target.value;
    issueStartedAt = {};
    saveLocalState();
    updateSetupSummaries();
  });

  document.getElementById("alert-delay").addEventListener("change", event => {
    settings.alertDelayMs = Number(event.target.value);
    issueStartedAt = {};
    saveLocalState();
    updateSetupSummaries();
  });

  document.getElementById("break-interval").addEventListener("change", event => {
    settings.breakIntervalMin = Number(event.target.value);
    saveLocalState();
    updateSetupSummaries();
    configureBreakTimer();
  });

  document.getElementById("btn-dismiss-break").addEventListener("click", event => {
    document.getElementById("break-reminder").hidden = true;
    event.currentTarget.disabled = true;
  });

  document.getElementById("btn-mute-alerts").addEventListener("click", toggleAlertsMute);
  updateMuteButton();

  document.getElementById("btn-presentation-mode").addEventListener("click", event => {
    presentationMode = !presentationMode;
    event.target.textContent = `Presentation mode: ${presentationMode ? "On" : "Off"}`;
    event.target.classList.toggle("btn-primary", presentationMode);
    event.target.classList.toggle("btn-secondary", !presentationMode);
    issueStartedAt = {};
  });
}

document.addEventListener("DOMContentLoaded", () => {
  initControls();
  initSocialFeatures();
});
